import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

export class Movies{
  constructor(
   public movieTheatersId:number,
   public TheaterName: string,
	public movieName:string,
	
	public movieDirector:string,
	public movieLength:string,
    public language:String
    ) {}
}

@Injectable({
  providedIn: 'root'
})
export class MovieTheaterService {
  
  movies: Movies[];
  constructor(private httpService: HttpClient) { }
 

  getMovieTheaters(){
    return this.httpService.get<Movies[]>("http://localhost:8084/getall")
  }
}
