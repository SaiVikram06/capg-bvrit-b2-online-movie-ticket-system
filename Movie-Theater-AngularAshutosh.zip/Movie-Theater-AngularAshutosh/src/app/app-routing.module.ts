import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListMovieTheatersComponent } from './list-movie-theaters/list-movie-theaters.component';


const routes: Routes = [
  {path:'listMovieTheaters',component:ListMovieTheatersComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
