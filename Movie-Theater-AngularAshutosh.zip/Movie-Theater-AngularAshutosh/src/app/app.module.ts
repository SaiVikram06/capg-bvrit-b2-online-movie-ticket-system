import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import { MovieTheaterService } from './Movie-Theater.service';
import { ListMovieTheatersComponent } from './list-movie-theaters/list-movie-theaters.component';


@NgModule({
  declarations: [
    AppComponent,
    ListMovieTheatersComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,FormsModule
  ],
  providers: [HttpClient,MovieTheaterService],
  bootstrap: [AppComponent]
})
export class AppModule { }
