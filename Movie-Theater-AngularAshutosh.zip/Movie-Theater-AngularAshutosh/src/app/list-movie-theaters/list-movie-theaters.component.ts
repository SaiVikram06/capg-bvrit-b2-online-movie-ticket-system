import { Component, OnInit } from '@angular/core';
import { MovieTheaterService, Movies} from '../Movie-Theater.service';
import { Router } from '@angular/router';
import { throwError } from 'rxjs';


@Component({
  selector: 'app-list-movie-theaters',
  templateUrl: './list-movie-theaters.component.html',
  styleUrls: ['./list-movie-theaters.component.css']
})
export class ListMovieTheatersComponent implements OnInit {

    movies:Movies[];
    tempMovies: Movies[];
    selType: String = "movieName";
  
  constructor(private movieService:MovieTheaterService,private router: Router) { }

  ngOnInit() {
    this.movieService.getMovieTheaters().subscribe(
      response=>{
        this.movies=response;
        this.tempMovies = this.movies.slice();
        console.log(response);
      }  )
  }
//  Here we select the movie or theater in dropdownbox and from that we search moviename or theatername
// then all the details are displayed
search(value){
 
  let type = "movieName";
    if(this.selType == 'movieName'){
      type = "movieName";
    }
    else
      type = "theaterName";
    this.movies = this.tempMovies;
    this.movies = this.movies.filter((item)=>{
      return item[type].toUpperCase().includes(value.target.value.toUpperCase());
    })
  }
  }



