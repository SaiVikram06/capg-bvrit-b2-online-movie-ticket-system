import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

export class City{
  static cityId: string;
  constructor(public cityId:number,public cityName:String){}
}
@Injectable({
  providedIn: 'root'
})
export class CityService {
  cities: City[];
  constructor(private httpService: HttpClient) { }

  addCity(cities):Observable<City> {
    console.log(cities);
      return this.httpService.post<City>("http://localhost:8091/city/add",cities);
  }
  public deleteCity(cities) {
    return this.httpService.delete<City>("http://localhost:8091/city/delete/"+ cities.cityId);
  }
  getAllCities(){
    return this.httpService.get<City[]>("http://localhost:8091/city/findallcities");
  }
  existsByName(cityName:String) {
    return this.httpService.get<boolean>("http://localhost:8091/city-check/{cityName}"+cityName);
  }

}
