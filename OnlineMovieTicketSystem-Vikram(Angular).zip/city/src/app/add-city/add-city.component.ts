import { Component, OnInit } from '@angular/core';
import { City, CityService } from '../movie-project.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-add-city',
  templateUrl: './add-city.component.html',
  styleUrls: ['./add-city.component.css']
})
export class AddMovieComponent implements OnInit {
  user:City= new City(0,"");

  constructor(private cityService:CityService,private router: Router) { }

  ngOnInit() {
  }
    addCity(): void{
      console.log(this.user);
   
      this.cityService.addCity(this.user).subscribe( data => { alert("City is added successfully.");});
    }

}
