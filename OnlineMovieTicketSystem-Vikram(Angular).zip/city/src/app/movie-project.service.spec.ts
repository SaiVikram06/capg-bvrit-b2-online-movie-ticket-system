import { TestBed } from '@angular/core/testing';

import { MovieProjectService } from './movie-project.service';

describe('MovieProjectService', () => {
  let service: MovieProjectService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MovieProjectService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
