import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddMovieComponent } from './add-city/add-city.component';
import { ListMovieComponent } from './list-city/list-movie.component'


const routes: Routes = [
  { path:'app-add-city', component:AddMovieComponent },
{ path:'app-list-city', component:ListMovieComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
