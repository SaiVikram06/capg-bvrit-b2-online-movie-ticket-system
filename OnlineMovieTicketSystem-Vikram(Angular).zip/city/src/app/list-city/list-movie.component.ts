import { Component, OnInit } from '@angular/core';
import { City, CityService } from '../movie-project.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-city',
  templateUrl: './list-movie.component.html',
  styleUrls: ['./list-movie.component.css']
})
export class ListMovieComponent implements OnInit {

  cities: City[];
  
  constructor(private cityService:CityService,private router: Router) { }

  ngOnInit() {
    this.cityService.getAllCities().subscribe(
      response =>this.handleSuccessfulResponse(response),
     );
  }
  handleSuccessfulResponse(response)
{
    this.cities=response;
}

  deleteCity(city: City): void {
    if(confirm("sure to delete")){
    this.cityService.deleteCity(city)
      .subscribe( data => {
        this.cities = this.cities.filter(u => u !== city);});
      }
  }
}

