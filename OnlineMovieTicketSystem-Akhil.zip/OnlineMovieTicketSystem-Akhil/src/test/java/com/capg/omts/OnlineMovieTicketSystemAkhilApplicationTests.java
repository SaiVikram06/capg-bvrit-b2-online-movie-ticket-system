package com.capg.omts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineMovieTicketSystemAkhilApplicationTests {

	@Test
	void contextLoads() {
	}

}
