package com.capg.omts.service;

import java.util.List;

import com.capg.omts.entity.CityBean;

public interface ICityService {

	public CityBean addCity(CityBean bean);
	
	public CityBean removeCity(int id);
	
	public List<CityBean> getAllCities();
	
	
}
