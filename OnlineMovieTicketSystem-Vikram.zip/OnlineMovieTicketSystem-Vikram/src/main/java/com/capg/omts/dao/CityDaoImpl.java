package com.capg.omts.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capg.omts.entity.CityBean;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;


@Repository
@Transactional
public class CityDaoImpl implements ICityDao{
	@PersistenceContext
	EntityManager entityManager;
	

	@Override
	public CityBean addCity(CityBean bean) {
		entityManager.persist(bean);
		 
		 return bean;
	}

	@Override
	public CityBean removeCity(int id) {
		CityBean bean = entityManager.find(CityBean.class, id);
		entityManager.remove(bean);
		return bean;
	}

	@Override
	public List<CityBean> getAllCities() {
		TypedQuery<CityBean> query = entityManager.createQuery("from CityBean", CityBean.class);
		return query.getResultList();
	}

}
