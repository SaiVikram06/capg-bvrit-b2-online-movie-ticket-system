package com.capg.omts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.omts.dao.CityDaoImpl;
import com.capg.omts.entity.CityBean;


@Service
public class CityServiceImpl implements ICityService{

	
	@Autowired
	CityDaoImpl dao;
	@Override
	public CityBean addCity(CityBean bean) {
		
		return dao.addCity(bean);
	}

	@Override
	public CityBean removeCity(int id) {
		return dao.removeCity(id);
	}

	@Override
	public List<CityBean> getAllCities() {
		
		return dao.getAllCities();
	}

}
