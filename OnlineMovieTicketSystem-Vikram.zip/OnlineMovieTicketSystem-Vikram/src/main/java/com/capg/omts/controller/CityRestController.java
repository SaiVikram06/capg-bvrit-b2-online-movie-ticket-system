package com.capg.omts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.capg.omts.entity.CityBean;
import com.capg.omts.service.CityServiceImpl;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class CityRestController {
	
	@Autowired
	CityServiceImpl cityServiceImpl;
	
	
	//dont give id, It is auto-generated
	//postman - post - http:localhost:8091/city/add
	@PostMapping("/city/add")
	public String addCity(@RequestBody CityBean bean)
	{
		CityBean bean1 = cityServiceImpl.addCity(bean);
		return bean1.getCityName()+" is succesfully added";
		
	}
	
	@GetMapping("/city/findallcities")       
	public List<CityBean> getall() {

		List<CityBean> bean = cityServiceImpl.getAllCities();
		return bean;
	}
	@DeleteMapping("/city/delete/{cityId}")  
	public String removeAccount(@PathVariable int cityId) throws Exception
	{
		CityBean bean= cityServiceImpl.removeCity(cityId);
		if(bean==null) {throw new Exception("Invalid id");
		}
		return bean.getCityName()+"\n  city deleted succesfully\n" + "of id:"+
		bean.getCityId();
	
	}

}
