package com.capg.omts.dao;

import java.util.List;


import com.capg.omts.entity.CityBean;

public interface ICityDao {
	
	public CityBean addCity(CityBean bean);
	
	public CityBean removeCity(int id);
	
	public List<CityBean> getAllCities();


}
