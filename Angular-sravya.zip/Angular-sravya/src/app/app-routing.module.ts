import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddComponent } from './add/add.component';
import { ListShowComponent } from './list-show/list-show.component';
import { DeleteComponent } from './delete/delete.component';

const routes: Routes = [
  {path:'addshow',component:AddComponent},
  {path:'deleteshow',component:DeleteComponent},
  {path:'listshow',component:ListShowComponent},
  ];
  
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }




