import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
export class Show{
  static showId: string;
constructor(
  public showId:number, public showTime:string,	public showName:string,	public movieName:string,public screenId:number,
) {}
}
@Injectable({
  providedIn: 'root'                                          
})
export class ShowService {
  shows: Show[];
  constructor(private httpService : HttpClient) { }
  addShow(shows):Observable<Show> {
    console.log(shows);
    return this.httpService.post<Show>("http://localhost:8090/show/create",shows);
  }
public deleteShowById(shows) {
  return this.httpService.delete<Show>("http://localhost:8090/show/removeById/"+ shows.showId);
}
getallShows(){
  return this.httpService.get<Show[]>("http://localhost:8090/show/findall")
}
}