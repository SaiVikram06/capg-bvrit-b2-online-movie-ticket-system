import { Component, OnInit } from '@angular/core';
import { Show, ShowService } from '../show.service';
import{Router}from '@angular/router';
@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {
 shows: Show[];
  constructor(private showservice:ShowService,private router:Router){}
  

  ngOnInit() {
    this.showservice.getallShows().subscribe(
      response =>this.handleSuccessfulResponse(response),);
      
  }
  handleSuccessfulResponse(response){
        
    this.shows= response;
  }

  deleteShowById(show: Show): void {
    if(confirm("sure to delete"))
    this.showservice.deleteShowById(show)
      .subscribe( data => {
        this.shows = this.shows.filter(u => u !== show); 
      })
  };
  }
