import { Component, OnInit } from '@angular/core';
import { Show, ShowService} from '../show.service';
import{Router}from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  user: Show = new Show(0,"","","",0);
  
  constructor(
    private showservice:ShowService,private router:Router){}
  

  ngOnInit(): void {}
addShow():void{
  console.log(this.user);
  this.showservice.addShow(this.user).subscribe(data =>{ alert("Show is added successfully.");});
}

}
