import { Component, OnInit } from '@angular/core';
import { Show,ShowService} from '../show.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-show',
  templateUrl: './list-show.component.html',
  styleUrls: ['./list-show.component.css']
})
export class ListShowComponent implements OnInit {
  shows: Show[];
  constructor(private showservice:ShowService,private router: Router) { }

  ngOnInit():void {
    this.showservice.getallShows().subscribe(
      response =>(this.handleSuccessfulResponse(response)),
     );
  }
  
  handleSuccessfulResponse(response){
        
    this.shows= response;
  }

  deleteShowById(show: Show): void {
    
  this.showservice.deleteShowById(show)
    .subscribe( data => {
      this.shows = this.shows.filter(u => u !== show); });
}
  }

