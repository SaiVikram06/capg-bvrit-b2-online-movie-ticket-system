import { Injectable, EventEmitter } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MoviedetailsService {
  
    //To emit Movie and Theatre to another component
    $movieDetails = new EventEmitter();
    
    constructor() { }

    sendMovieDetails(movie){

      this.$movieDetails.emit(movie);

    }
}
