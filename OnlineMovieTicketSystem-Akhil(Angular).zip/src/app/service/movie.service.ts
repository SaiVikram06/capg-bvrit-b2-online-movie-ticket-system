import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

 //BEANS//
    
    export class Movie{
        constructor(
            public name:string,
            public theatre:string,
        ) {}
    }

    export class Booking{
        constructor(
             public bookingId:number,
             public movieName:string,
             public theatreName:string,
             public customerName:string,
             public emailId:string,
             public phno:string,
             public paymentMethod:string,
             public seats:number
         ){}
    }

@Injectable({
  providedIn: 'root'
})
export class MovieService {

  movies:Movie[]=[];
  
  booking:Booking = new Booking(0,"","","","","","",0);
  
  //To emit entered booking details to another component
  $bookingDetails = new EventEmitter();

   //Constructor Injections for HttpClient(to handle request and response)
    constructor(private httpClient:HttpClient , private router: Router) { } 

      //Storing Movie List from json file
      display(){
            this.httpClient.get<Movie[]>('./assets/Movies.json').subscribe(response =>{
                for(let m of response){
                let movie = new Movie(m.name,m.theatre);
                this.movies.push(movie);
                }
              }
            );
       } 

       //Getting Movie List
       getMovies(): Movie[]{
           return this.movies;
       }
  
      //Setting Movie And Theatre
       setMovieDetails(movie){
       console.log("Changing From Movie to Booking Done");
       this.booking.movieName = movie.name;
       this.booking.theatreName = movie.theatre;
       console.log(this.booking);
      }
      
      //Adding The New Booking to Database using POST 
      createBooking(bookingfinal):Observable<Booking> {
      this.booking.customerName = bookingfinal.customerName;
      this.booking.emailId = bookingfinal.emailId;
      this.booking.paymentMethod = bookingfinal.paymentMethod;
      this.booking.phno = bookingfinal.phno;
      this.booking.seats = bookingfinal.seats;
      console.log(this.booking);
      this.$bookingDetails.emit(this.booking);
      this.router.navigate(['/movieticket']);
          
          return this.httpClient.post<Booking>("http://localhost:8096/booking", this.booking);
      }

      //Retreiving the booking list from Database using GET Method
      getAllBookings(){
          return this.httpClient.get<Booking[]>("http://localhost:8096/booking");
      }

      //Delete Particular Booking by sending particular ID 
      cancelBooking(booking){
           return this.httpClient.delete<Booking>("http://localhost:8096/booking"+"/"+booking.bookingId);
      }

      showTicket(bookingId){
        return this.httpClient.get<Booking>("http://localhost:8096/booking"+"/"+bookingId);
      }
}
 
