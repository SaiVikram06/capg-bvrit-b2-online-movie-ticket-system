import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { MovieListComponent } from './movie-list/movie-list.component';
import { MovieBookingComponent } from './movie-booking/movie-booking.component';
import { MovieTicketComponent } from './movie-ticket/movie-ticket.component';
import { MovieBookingListComponent } from './movie-booking-list/movie-booking-list.component';
import { ShowTicketComponent } from './show-ticket/show-ticket.component';


const routes: Routes = [{
  path:'login',
  component:LoginComponent
},
{
  path:'movielist',
  component:MovieListComponent
},
{
  path:'bookmovie',
  component:MovieBookingComponent
},
{
  path:'movieticket',
  component:MovieTicketComponent
},
{
  path:'bookinglist',
  component:MovieBookingListComponent
},
{
  path:'showticket/:id',
  component:ShowTicketComponent
}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
